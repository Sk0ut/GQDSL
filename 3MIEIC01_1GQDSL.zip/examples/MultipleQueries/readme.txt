Upon the compilation of this file it's expected that
only on imports set is present, despite the multiple
queries present in it.