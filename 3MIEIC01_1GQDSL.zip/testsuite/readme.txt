Most of the testing was done by checking for errors in compilation
or checking the results obtained by the developed queries.
So no automated testing was developed.