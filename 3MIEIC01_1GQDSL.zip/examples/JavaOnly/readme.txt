It is expected that the only change on this file upon 
compilation is the addition of import statements.
The java code must remain the same.