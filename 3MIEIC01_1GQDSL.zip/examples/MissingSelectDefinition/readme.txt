It is expected that the compilation of this file fails,
due to lack of definition of one select parameter.