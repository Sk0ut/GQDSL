This file should compile to a correct Java file,
ready to be compiled (dependencies must be linked)
and executed, displaying the results of the queries
in it.