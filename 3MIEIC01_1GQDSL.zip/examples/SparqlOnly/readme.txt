The compiler is expected to compile a SPARQL only file,
by inserting the needed imports and replacing the query
with a snippet of Java code that loads the graph and
executes the query.